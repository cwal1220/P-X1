package com.serenegiant.widget;

/**
 * Created by Administrator on 2018/4/2 0002.
 */

public class TouchPoint {
    public float x;
    public float y;
    public int numOfPoint;
    public float temp;
    //public  boolean inUse;
    //public  boolean needShow;
}
