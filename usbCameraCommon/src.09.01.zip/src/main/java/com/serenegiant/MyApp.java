package com.serenegiant;

import android.app.Application;

public class MyApp extends Application {
    public static String deviceName="";
}
