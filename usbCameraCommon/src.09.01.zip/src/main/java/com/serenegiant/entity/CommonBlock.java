package com.serenegiant.entity;

/**
 * @author yp2
 * @date 2015-11-18
 * @description 通用数据块
 */
public class CommonBlock extends DataBlock {

	public void setData(byte[] data) {
		this.data = data;
	}
	

}
