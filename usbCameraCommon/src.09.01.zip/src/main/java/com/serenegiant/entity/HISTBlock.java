package com.serenegiant.entity;

/**
 * Created by jun on 2018/8/4.
 */

public class HISTBlock extends DataBlock {
    @Override
    public void setData(byte[] data) {
        this.data = data;
    }
}
