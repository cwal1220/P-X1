package com.serenegiant.entity;

/**
 * @author yp2
 * @date 2015-11-18
 * @description tRNS数据块
 */
public class TRNSBlock extends DataBlock{
	
	public void setData(byte[] data) {
		this.data = data;
	}
	
}
