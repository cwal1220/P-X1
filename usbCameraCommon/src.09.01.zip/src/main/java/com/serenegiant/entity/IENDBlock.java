package com.serenegiant.entity;

/**
 * @author yp2
 * @date 2015-11-18
 * @description IEND数据块
 */
public class IENDBlock extends DataBlock{

	@Override
	public void setData(byte[] data) {
		this.data = data;
	}
	
}
