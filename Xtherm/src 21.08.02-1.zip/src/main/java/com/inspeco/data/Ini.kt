package com.inspeco.data

import android.os.Environment
import com.google.gson.Gson
import java.io.*
import java.util.*


class PLList(pl:ArrayList<DiagData>) : Serializable {
    var pls:ArrayList<DiagData> = pl
}


class CondList(cond:ArrayList<ConditionData>) : Serializable {
    var conds:ArrayList<ConditionData> = cond
}


class EquipList(equip:ArrayList<EquipmentData>) : Serializable {
    var lists:ArrayList<EquipmentData> = equip
}

class VoltList(volt:ArrayList<VoltData>) : Serializable {
    var lists:ArrayList<VoltData> = volt
}

object Ini {

    /**
     *  상태판정에 필요한 ini 파일이 있는지 체크한다. 없으면 새로 생성한다
     */

    private fun getStrFromFile(aFile: File): String {
        val fis = FileInputStream(aFile)
        val buffer = ByteArray(fis.available())
        fis.read(buffer)
        fis.close()
        return String(buffer)

    }


    var diagPLList: ArrayList<DiagData> = arrayListOf<DiagData>()
    var conditionList: ArrayList<ConditionData> = arrayListOf<ConditionData>()
    var equipmentList: ArrayList<EquipmentData> = arrayListOf<EquipmentData>()
    var diagVoltDistList: ArrayList<VoltData> = arrayListOf<VoltData>()
    var diagVoltTransList: ArrayList<VoltData> = arrayListOf<VoltData>()



    private fun loadDefaultTransVolt() {
        diagVoltTransList.clear()
        diagVoltTransList.add(VoltData( volt= 5000f, value = 1.0f))
        diagVoltTransList.add(VoltData( volt=10000f, value = 2.0f))
        diagVoltTransList.add(VoltData( volt=15000f, value = 3.0f))
        diagVoltTransList.add(VoltData( volt=9999000f, value = 4.0f))
    }

    private fun loadDefaultDistVolt() {
        diagVoltDistList.clear()
        diagVoltDistList.add(VoltData( volt= 5000f, value = 1.0f))
        diagVoltDistList.add(VoltData( volt=10000f, value = 2.0f))
        diagVoltDistList.add(VoltData( volt=15000f, value = 3.0f))
        diagVoltDistList.add(VoltData( volt=9999000f, value = 4.0f))
    }



    private fun loadDefaultPl() {
        diagPLList.clear()
        diagPLList.add(DiagData( id=1, name="PL1", value=2.0f, msg="7일이내 재점검"))
        diagPLList.add(DiagData( id=2, name="PL2", value=-1.0f, msg="1개월이내 재점검"))
        diagPLList.add(DiagData( id=3, name="PL3", value=-3.5f, msg="3개월이내 재점검"))
        diagPLList.add(DiagData( id=4, name="PL4", value=-6.0f, msg="6개월이내 재점검"))
        diagPLList.add(DiagData( id=5, name="PL5", value=-8.49f, msg="9개월이내 재점검"))
        diagPLList.add(DiagData( id=6, name="PL6", value=-8.5f, msg="12개월이내 재점검"))
    }

    private fun loadDefaultCondition() {
        conditionList.clear()
        conditionList.add(ConditionData( name="균열", value=0.315f))
        conditionList.add(ConditionData( name="침식", value = 0.226f))
        conditionList.add(ConditionData( name="과열흔", value = 0.200f))
        conditionList.add(ConditionData( name="섬락", value = 0.200f))
        conditionList.add(ConditionData( name="오염", value = 0.045f))
        conditionList.add(ConditionData( name="무광", value = 0.028f))
        conditionList.add(ConditionData( name="파손", value = 0.250f))
        conditionList.add(ConditionData( name="부식(녹)", value = 0.153f))
        conditionList.add(ConditionData( name="설치불량", value = 0.048f))
        conditionList.add(ConditionData( name="탈락", value = 0.048f))
        conditionList.add(ConditionData( name="외부이물질", value = 0.028f))
        conditionList.add(ConditionData( name="수목접촉", value = 0.028f))
        conditionList.add(ConditionData( name="외관양호", value = 0.0f))
        conditionList.add(ConditionData( name="탄화", value = 0.086f))
        conditionList.add(ConditionData( name="표면박리", value = 0.037f))
        conditionList.add(ConditionData( name="기타", value = 0.016f))
    }

    private fun loadDefaultEquipment() {
        equipmentList.clear()
        equipmentList.add(EquipmentData( eType=1, name="피복전선", imgName = "item_equip_01",  rfRate=0.943f ))
        equipmentList.add(EquipmentData( eType=1, name="현수애자(자기)", imgName = "item_equip_02",  rfRate=0.83f, value = 0.105f ))
        equipmentList.add(EquipmentData( eType=1, name="LP애자(자기)", imgName = "item_equip_03",  rfRate=0.86f, value = 0.297f ))
        equipmentList.add(EquipmentData( eType=1, name="피뢰기(자기)", imgName = "item_equip_04",  rfRate=0.852f ))
        equipmentList.add(EquipmentData( eType=1, name="COS(자기재)", imgName = "item_equip_05",  rfRate=0.86f, value = 0.091f ))
        equipmentList.add(EquipmentData( eType=1, name="완철류", imgName = "item_equip_06",  rfRate=0.3f ))
        equipmentList.add(EquipmentData( eType=1, name="카바류", imgName = "item_equip_07",  rfRate=0.945f ))
        equipmentList.add(EquipmentData( eType=1, name="폴리머", imgName = "item_equip_08",  rfRate=0.94f ))
        equipmentList.add(EquipmentData( id=1, eType=2, name="MCCB", subName = " 단자", imgName = "item_equip2_01_00", baseOndo = 60f, rfRate=0.945f ))
//        EquipmentData( id=2, eType=2, name="커버나이프 스위치", subName = "단자부", imgName = "", baseOndo = 50f, rfRate=0.8f,value = 0.07f ))
//        EquipmentData( id=2, eType=2, name="커버나이프 스위치", subName = "개폐접촉부", imgName = "", baseOndo = 50f, rfRate=0.8f,value = 0.07f ))
//        EquipmentData( id=2, eType=2, name="커버나이프 스위치", subName = "퓨즈나사머리부", imgName = "", baseOndo = 60f, rfRate=0.8f,value = 0.07f ))
        equipmentList.add(EquipmentData( id=3, eType=2, name="전력퓨즈", subName = " 접속부", imgName = "item_equip2_02_01", baseOndo = 75f, rfRate=0.8f ))
        equipmentList.add(EquipmentData( id=3, eType=2, name="전력퓨즈", subName = " 접촉부", imgName = "item_equip2_02_02", baseOndo = 80f, rfRate=0.8f ))
        equipmentList.add(EquipmentData( id=3, eType=2, name="전력퓨즈", subName = " 기계적구조부", imgName = "item_equip2_02_03", baseOndo = 90f, rfRate=0.9f ))
        equipmentList.add(EquipmentData( id=4, eType=2, name="계기용변성기", subName = " 단자부", imgName = "item_equip2_03_01", baseOndo = 75f, rfRate=0.9f ))
        equipmentList.add(EquipmentData( id=4, eType=2, name="계기용변성기", subName = " 본체", imgName = "item_equip2_03_02", baseOndo = 95f, rfRate=0.6f ))
        equipmentList.add(EquipmentData( id=5, eType=2, name="변압기", subName = " 표면온도", imgName = "item_equip2_04_00", baseOndo = 95f, rfRate=0.6f, value = 0.045f))
        equipmentList.add(EquipmentData( id=6, eType=2, name="MOLD 변압기", subName = " 철심부", imgName = "item_equip2_05_01", baseOndo = 120f, rfRate=0.95f, value = 0.045f ))
        equipmentList.add(EquipmentData( id=6, eType=2, name="MOLD 변압기", subName = " 에폭시", imgName = "item_equip2_05_02", baseOndo = 80f, rfRate=0.9f,value = 0.045f  ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="케이블", subName = " IV", imgName = "item_equip2_06_01", baseOndo = 60f, rfRate=0.943f, value = 0.297f ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="케이블", subName = " HIV", imgName = "item_equip2_06_02", baseOndo = 75f, rfRate=0.943f, value = 0.297f ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="케이블", subName = " EV", imgName = "item_equip2_06_03", baseOndo = 75f, rfRate=0.943f, value = 0.297f ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="케이블", subName = " CV", imgName = "item_equip2_06_04", baseOndo = 90f, rfRate=0.943f, value = 0.297f ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="케이블", subName = " VVF", imgName = "item_equip2_06_05", baseOndo = 60f, rfRate=0.943f, value = 0.297f ))
        equipmentList.add(EquipmentData( id=7, eType=2, name="콘덴서", subName = " 단자부", imgName = "item_equip2_07_01", baseOndo = 75f, rfRate=0.94f ))
        equipmentList.add(EquipmentData( id=6, eType=2, name="콘덴서", subName = " 본체", imgName = "item_equip2_07_02", baseOndo = 65f, rfRate=0.25f ))
    }





    private fun loadPlData() {
        val plFile = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/" + Consts.DIAGNOSIS_PL)
        if (!plFile.exists()) {
            // 파일이 없으면 생성한다

            loadDefaultPl()
            var pllist = PLList(diagPLList)

            val gson = Gson()
            val json = gson.toJson(pllist, PLList::class.java)

            val buf = BufferedWriter(FileWriter(plFile, true))
            buf.append(json)
            buf.close()
        } else {
            try {
                val str = getStrFromFile(plFile)
                val pl = Gson().fromJson(str, PLList::class.java)
                diagPLList.clear()
                for (i in 0 until pl.pls.size) {
                    diagPLList.add(pl.pls[i])
                }
            } catch (e: Exception) {
                e.printStackTrace()
                loadDefaultCondition()
            }
        }
    }


    private fun loadConditionData() {
        val hFile = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/" + Consts.DIAGNOSIS_COND)
        if (!hFile.exists()) {
            // 파일이 없으면 생성한다

            loadDefaultCondition()
            var condlist = CondList(conditionList)

            val gson = Gson()
            val json = gson.toJson(condlist, CondList::class.java)

            val buf = BufferedWriter(FileWriter(hFile, true))
            buf.append(json)
            buf.close()
        } else {
            try {
                val str = getStrFromFile(hFile)
                val cond = Gson().fromJson(str, CondList::class.java)
                conditionList.clear()
                for (i in 0 until cond.conds.size) {
                    conditionList.add(cond.conds[i])
                }
            } catch (e: Exception) {
                e.printStackTrace()
                loadDefaultCondition()
            }
        }
    }




    private fun loadEquipData() {
        val hFile = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/" + Consts.DIAGNOSIS_EQUIP)
        if (!hFile.exists()) {
            // 파일이 없으면 생성한다

            loadDefaultEquipment()
            var equiplist = EquipList(equipmentList)

            val gson = Gson()
            val json = gson.toJson(equiplist, EquipList::class.java)

            val buf = BufferedWriter(FileWriter(hFile, true))
            buf.append(json)
            buf.close()
        } else {
            try {
                val str = getStrFromFile(hFile)
                val equip = Gson().fromJson(str, EquipList::class.java)
                equipmentList.clear()
                for (i in 0 until equip.lists.size) {
                    equipmentList.add(equip.lists[i])
                }
            } catch (e: Exception) {
                e.printStackTrace()
                loadDefaultEquipment()
            }
        }
    }



    private fun loadDistVoltData() {
        val hFile = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/" + Consts.DIAGNOSIS_DVOLT)
        if (!hFile.exists()) {
            // 파일이 없으면 생성한다

            loadDefaultDistVolt()
            var voltlist = VoltList(diagVoltDistList)

            val gson = Gson()
            val json = gson.toJson(voltlist, VoltList::class.java)

            val buf = BufferedWriter(FileWriter(hFile, true))
            buf.append(json)
            buf.close()
        } else {
            try {
                val str = getStrFromFile(hFile)
                val volt = Gson().fromJson(str, VoltList::class.java)
                diagVoltDistList.clear()
                for (i in 0 until volt.lists.size) {
                    diagVoltDistList.add(volt.lists[i])
                }
            } catch (e: Exception) {
                e.printStackTrace()
                loadDefaultDistVolt()
            }
        }
    }



    private fun loadTransVoltData() {
        val hFile = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/" + Consts.DIAGNOSIS_TVOLT)
        if (!hFile.exists()) {
            // 파일이 없으면 생성한다

            loadDefaultTransVolt()
            var voltlist = VoltList(diagVoltTransList)

            val gson = Gson()
            val json = gson.toJson(voltlist, VoltList::class.java)

            val buf = BufferedWriter(FileWriter(hFile, true))
            buf.append(json)
            buf.close()
        } else {
            try {
                val str = getStrFromFile(hFile)
                val volt = Gson().fromJson(str, VoltList::class.java)
                diagVoltTransList.clear()
                for (i in 0 until volt.lists.size) {
                    diagVoltTransList.add(volt.lists[i])
                }
            } catch (e: Exception) {
                e.printStackTrace()
                loadDefaultTransVolt()
            }
        }
    }


    fun checkIniFile() {

        // 루트 폴더 체크
        val folder = File(Environment.getExternalStorageDirectory().absolutePath + "/" + Consts.ROOT_FOLDER + "/")
        if (!folder.exists()) {
            folder.mkdir()
        }

        loadPlData()
        loadConditionData()
        loadEquipData()
        loadDistVoltData()
        loadTransVoltData()

    }
}