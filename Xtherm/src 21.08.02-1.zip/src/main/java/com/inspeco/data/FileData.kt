package com.inspeco.data


import java.io.Serializable

/**
 * File Data
 */
class FileData : Serializable{
    var fileName = ""
    var filePath = ""
    var isSelect = false
    var isPlay = false
}