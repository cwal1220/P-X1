package com.inspeco.X1.상태판정뷰

import android.content.Context
import android.content.Intent
import android.graphics.Point
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import com.inspeco.X1.R
import com.inspeco.X1.XTerm.ByteUtil
import com.inspeco.data.Cfg
import com.inspeco.data.Consts
import com.inspeco.data.States
import com.inspeco.data.stringFromFloatAuto
import kotlinx.android.synthetic.main.fragment_diag_ondo.*
import kotlinx.android.synthetic.main.fragment_diag_ondo.view.*
import java.io.File
import java.io.FileInputStream


class DiagOndoFragment() : Fragment() {
    private val TAG = "bobopro-DiagMixFragment"
    private lateinit var mContext: Context

    private lateinit var mView: View
    /**
     * 복합진단 Fragment Create
     */
    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?,
    ): View? {
        Log.d(TAG, "onCreateView")

        val view: View = inflater!!.inflate(R.layout.fragment_diag_ondo, container, false)
        mView = view
        States.diagPage = 0
        view.videoLabel.text = States.diagImageFile.fileName

        updateOndoTypeUi()
        updateVoltUi()
        view.equipmentLabel.text = States.diagEquipment.name
        updateBaseOndoUi()

        updateOndoListUi()
        updateMaterialUi()

        updatePageUI()

        // 다음 설정,   결과 확인...
        view.nextButton.setOnClickListener {

            if (States.diagPage==0) {
                States.diagPage = 1
            } else if (States.diagPage==1) {
                States.diagPage = 1
                var isOk = true
                if (States.diagImageFile.fileName == "") isOk = false
                if (States.diagOndoType == 0) isOk = false
                if (States.diagFacility == 0) isOk = false
                if (States.diagVolt == 0f) isOk = false
                if (States.diagEquipment.name == "") isOk = false
                if (States.diagBaseOndo == 0f) isOk = false
                if (States.diagMaterial.name=="") isOk = false

                if (isOk) {
                    var intent = Intent(mContext, ResultOndoActivity::class.java)
                    startActivity(intent)
                } else {
                    val toast = Toast.makeText(mContext, "모든 진단 항목을 완료해주세요.", Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
                    toast.show()
                }
            }
            updatePageUI()
        }


        view.openImageButton.setOnClickListener{
            openImage()
        }

        view.openOndoTypeButton.setOnClickListener{
            val dialog = SelectABDialog(mContext, States.diagOndoType)
            dialog.setSaveClickListener {
                updateOndoTypeUi()
            }
            dialog.show()
        }

        view.openVoltButton.setOnClickListener{
            val dialog = SelectVoltDialog(mContext, States.diagFacility, States.diagVolt)
            dialog.setSaveClickListener {
                updateVoltUi()
            }
            dialog.show()
        }


        view.openEquipmentButton.setOnClickListener{
            if (States.diagFacility==0) {
                val toast = Toast.makeText(mContext,"설비를 먼저 선택하여 주세요.", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
                toast.show()
            } else {
                val dialog = EquipmentListDialog(mContext)
                dialog.setItemClickListener {
                    mView.equipmentLabel.text = States.diagEquipment.name
                    if (States.diagEquipment.baseOndo>0f) {
                        States.diagBaseOndo = States.diagEquipment.baseOndo
                    } else {
                        States.diagBaseOndo =  States.diagWaveInfo.ondo
                    }
                    updateBaseOndoUi()
                }
                val windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val display = windowManager.defaultDisplay
                val size = Point()
                //Log.d(TAG, "width ${size.x}")
                display.getSize(size)
                val params: ViewGroup.LayoutParams? = dialog?.window?.attributes
                params?.width = size.x - 100
                params?.height = size.y - 50
                dialog.window?.attributes = params as WindowManager.LayoutParams
                dialog.show()
            }
        }

        view.openMaterialButton.setOnClickListener {
            val dialog = SelectMaterialDialog(mContext)
            dialog.setSelectItemListener() {
                updateMaterialUi()
            }
            dialog.show()
        }



        view.openOndoListButton.setOnClickListener{
            // 3상 비교법일때 지정 가능
            if (States.diagOndoType == Consts.Diag_3Sang) {

                if (States.diagOndoList.size>0) {
                    val dialog = OndoListDialog(mContext)
                    dialog.setSaveClickListener {
                        updateOndoListUi()
                    }
                    dialog.show()
                } else {
                    val toast = Toast.makeText(mContext,"설정된 포인트 온도가 없습니다.", Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
                    toast.show()
                }

            } else {
                val toast = Toast.makeText(mContext,"3상 비교법을 선택하여 주세요!", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
                toast.show()
            }


        }



        view.openOndoBaseButton.setOnClickListener {
            val dialog = EditOndoDialog(mContext, States.diagBaseOndo)
            dialog.setSaveClickListener() {
                updateBaseOndoUi()
            }
            dialog.show()
        }


        return view
    }


    private fun updateMaterialUi() {
        mView.materialLabel.text = States.diagMaterial.name
    }

    private fun updateOndoListUi() {
        var sText = ""
        var idx = 0
        var aChar = 'A'

        States.diagOndoList.forEach {
            aChar = 'A' + idx
            sText += aChar + " " + stringFromFloatAuto( Cfg.getOndoFC(it) ) + "°"+Cfg.p1_cGiho+"   "
            if ((idx % 3) == 2) {
                sText += "\n"
            }
            idx += 1
        }
        mView.ondoListLabel.text = sText
    }


    private fun updateBaseOndoUi() {
        if (States.diagBaseOndo>0f) {
            mView.baseOndoLabel.text = stringFromFloatAuto(Cfg.getOndoFC( States.diagBaseOndo)) + "°"+ Cfg.p1_cGiho
        } else {
            mView.baseOndoLabel.text = ""
        }
    }




    private fun updateVoltUi() {
        if (States.diagVolt>0) {
            val sVolt = stringFromFloatAuto(States.diagVolt) + "kV"
            when (States.diagFacility) {
                Consts.Diag_FacilitySupply -> mView.itemVoltLabel.text = "송전 " + sVolt
                Consts.Diag_FacilitySend -> mView.itemVoltLabel.text = "배전 " + sVolt
                Consts.Diag_FacilityTrans -> mView.itemVoltLabel.text = "변전 " + sVolt
                else -> mView.itemVoltLabel.text = ""
            }
        } else {
            mView.itemVoltLabel.text = ""
        }
    }

    private fun updateOndoTypeUi() {
        when (States.diagOndoType) {
            Consts.Diag_3Sang -> mView.ondoTypeLabel.text = "3상 비교법"
            Consts.Diag_OndoPattern -> mView.ondoTypeLabel.text = "온도 패턴법"
            else -> mView.ondoTypeLabel.text = ""
        }
    }


    /**
     * 이미지 선택창 열기
     */
    private fun openImage() {
        val dialog = ImageListDialog(mContext)

        if (dialog.fileList.size > 0) {
            val windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val display = windowManager.defaultDisplay
            val size = Point()
            display.getSize(size)
            val params: ViewGroup.LayoutParams? = dialog?.window?.attributes

            params?.width = size.x - 100
            params?.height = size.y - 50
            dialog.window?.attributes = params as WindowManager.LayoutParams

            dialog.show()

            dialog.setVideoClickListener {
                videoLabel.text = States.diagImageFile.fileName
                val file = File(States.diagImageFile.filePath)
                val fis = FileInputStream(file)
                val buffer = ByteArray(fis.available())
                fis.read(buffer)
                fis.close()
                val bufSize = buffer.size
                val checkEtx = ByteUtil.getInt(buffer, bufSize-4 )
                if (checkEtx==65538) {
                    States.diagTargetOndo = ByteUtil.getFloat(buffer, bufSize-28 )
                    val ondo1 = ByteUtil.getFloat(buffer, bufSize-8 )
                    val touchCount = ByteUtil.getInt(buffer, bufSize-32 )

                    States.diagLati  = ByteUtil.getFloat(buffer, bufSize-20 )
                    States.diagLongi = ByteUtil.getFloat(buffer, bufSize-16 )
                    States.diagOndo = ByteUtil.getFloat(buffer, bufSize-8 )
                    States.diagHumi = ByteUtil.getFloat(buffer, bufSize-12 )

                    States.diagOndoList.clear()
                    if ((touchCount>0) || (touchCount<=10) ) {
                        var bufIndex = bufSize - 36;
                        for (i in 0 until touchCount) {
                            val ondo = ByteUtil.getFloat(buffer, bufIndex )
                            bufIndex -= 4;
                            States.diagOndoList.add(0, ondo)
                            Log.d(TAG, "ondo, ${ondo}")
                        }
                    }

                    updateOndoListUi()

                    Log.d(TAG, "Load size:${bufSize}, touch Count:${touchCount}, etx:${checkEtx}, diagTargetOndo:${States.diagTargetOndo}, ondo:${ondo1}")
                    Log.d(TAG, "lati:${States.diagLati}, longi:${States.diagLongi}")
                } else {
                    val toast = Toast.makeText(mContext,"캡쳐파일 버젼체크 실패.", Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
                    toast.show()

                }


            }

        } else {
            val toast = Toast.makeText(mContext,"파일이 없습니다.", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, -200)
            toast.show()
        }
    }



    override fun onAttach(context: Context) {
        super.onAttach(context)
        //Log.d(TAG, "onAttatched")
        mContext = context

    }



    fun updatePageUI() {
        if (States.diagPage == 0) {
            mView.page_layout1.visibility = View.VISIBLE
            mView.page_layout2.visibility = View.GONE
            mView.nextButton.text = "다음 설정"
        } else {
            mView.page_layout1.visibility = View.GONE
            mView.page_layout2.visibility = View.VISIBLE
            mView.nextButton.text = "결과 확인"
        }
    }


    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                DiagOndoFragment().apply {
                }
    }
}