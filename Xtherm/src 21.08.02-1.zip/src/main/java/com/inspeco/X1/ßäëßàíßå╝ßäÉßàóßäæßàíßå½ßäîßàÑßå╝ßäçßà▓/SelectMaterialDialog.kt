package com.inspeco.X1.상태판정뷰

import android.app.Dialog
import android.content.Context
import android.view.View
import android.view.Window
import com.inspeco.X1.R
import com.inspeco.data.Consts
import com.inspeco.data.MaterialData
import com.inspeco.data.States
import kotlinx.android.synthetic.main.d_select_abcd.*


/**
 * Select Material 다이얼로그
 */
class SelectMaterialDialog(context: Context) : Dialog(context) {
    private val TAG = "bobopro-SelectABDialog"
    private var selItemClick: View.OnClickListener? = null


    /**
     * 초기화
     */
    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window!!.setBackgroundDrawableResource(android.R.color.transparent)
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        setContentView(R.layout.d_select_abcd)

        selectAButton.setOnClickListener {
            States.diagMaterial = MaterialData(Consts.Diag_MaterialCeramic,"사기", 0f)
            dismiss()
            selItemClick?.onClick(it)
        }

        selectBButton.setOnClickListener {
            States.diagMaterial = MaterialData(Consts.Diag_MaterialPolymer,"폴리", 0f)
            dismiss()
            selItemClick?.onClick(it)
        }

        selectCButton.setOnClickListener {
            States.diagMaterial = MaterialData(Consts.Diag_MaterialGlass,"유리", 0f)
            dismiss()
            selItemClick?.onClick(it)
        }

        selectDButton.setOnClickListener {
            States.diagMaterial = MaterialData(Consts.Diag_MaterialEtc,"기타", 0f)
            dismiss()
            selItemClick?.onClick(it)
        }



    }



    fun setSelectItemListener(clickListener: View.OnClickListener?) {
        this.selItemClick = clickListener
    }


//    fun setSel01Listener(sel01: View.OnClickListener) {
//        this.sel01Click = sel01
//    }
//
//    fun setSel02Listener(sel02: View.OnClickListener?) {
//        this.sel02Click = sel02
//    }


}